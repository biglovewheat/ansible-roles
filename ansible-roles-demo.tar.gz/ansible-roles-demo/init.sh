ansible-playbook -i ansible-host.lst  linux-init.yml
#ansible-playbook -i ansible-host.lst -C init.yml
