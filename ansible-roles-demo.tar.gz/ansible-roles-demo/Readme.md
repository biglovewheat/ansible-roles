




comfirm ./file/hosts
